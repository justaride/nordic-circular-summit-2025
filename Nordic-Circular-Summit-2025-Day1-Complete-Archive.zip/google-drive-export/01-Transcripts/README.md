# 01-Transcripts

Complete session transcripts from Nordic Circular Summit 2025 - Day 1

## Contents

### Session Files (6 sessions)

Each session includes three files:
1. **Clean Markdown** (`*-CLEAN.md`) - Human-readable formatted transcript
2. **Structured JSON** (`*.json`) - Machine-readable data with metadata
3. **Speaker Identification** (`*-SPEAKER-IDENTIFICATION.md`) - Voice pattern analysis

### Sessions Included

| Session | Title | Duration | Words | Speakers |
|---------|-------|----------|-------|----------|
| Session 1 | Circular Frontiers | ~60 min | 49,585 | 5 |
| Session 2 | Circular Ocean | ~60 min | 49,973 | 4 |
| Session 3 | Locally Rooted Solutions | ~50 min | 46,775 | 4 |
| Session 4 | Arctic Lifestyles | ~60 min | 57,703 | 5 |
| Session 5 | Circular Cities | ~70 min | 65,816 | 4 |
| Day 1 Summary | Reflections & Synthesis | ~30 min | 18,325 | 2 |

**Total:** 288,177 words across 5.5 hours

## File Format Guide

### Clean Markdown Files (*-CLEAN.md)
- Formatted for easy reading
- Speaker labels and timestamps
- Paragraph breaks for clarity
- Suitable for presentations, reports, reference

**Example structure:**
```markdown
# Session Title

**Speaker Name** [00:12:34]
Content of what they said...

**Moderator** [00:15:20]
Content continues...
```

### JSON Files (*.json)
- Structured data format
- Complete metadata (date, location, speakers, duration)
- Individual speaker turns with timestamps
- Theme tags and quote extraction
- Suitable for analysis, database import, custom processing

**Data structure:**
```json
{
  "session_id": "session-1",
  "title": "...",
  "metadata": {...},
  "speakers": [...],
  "turns": [
    {
      "speaker": "...",
      "timestamp": "00:12:34",
      "content": "...",
      "themes": [...]
    }
  ],
  "quotes": [...]
}
```

### Speaker Identification Files
- Technical analysis of voice patterns
- Speaker attribution methodology
- Confidence levels for identification
- Useful for understanding transcript accuracy

## Usage Recommendations

### For Quick Reference
→ Use Clean Markdown files

### For Analysis
→ Use JSON files with Python, R, or analysis tools

### For Verbatim Quotes
→ Reference Clean Markdown with timestamps

### For Speaker Research
→ Check Speaker Identification docs

## Integration

These transcripts are referenced throughout:
- `02-Articles/` - Articles synthesize transcript content
- `03-Highlights/` - Key quotes extracted from transcripts
- `04-Social-Media/` - Posts reference transcript themes
- `05-Executive-Summaries/` - Strategic insights from transcripts
- `06-Data-Files/` - Aggregated transcript data

## Notes

- All timestamps are in HH:MM:SS format
- Speaker names verified against event program
- Minor speaking errors preserved for authenticity
- [inaudible] marks unclear audio sections
- [crosstalk] indicates overlapping speech
