# Session 2: Speaker Identification Guide
## Circular Ocean Industries

**Date**: November 19, 2025
**Session Time**: 10:45-11:45 (60 minutes)
**Location**: Hans Egede Hotel, Nuuk, Greenland
**Format**: Panel Discussion with remote participant

---

## 🎯 Speaker Mapping

| Whisper ID | Actual Name | Organization | Confidence |
|------------|-------------|--------------|------------|
| Speaker 1 | Cathrine Barth | Natural State (Moderator) | 95% |
| Speaker 2 | Alexandra Leeper | Iceland Ocean Cluster | 100% |
| Speaker 3 | Kristian S. Ottesen | Royal Greenland | 100% |
| Speaker 6 | Michaela Lindström | Hylia Nordic | 100% |
| Speaker 7 | Linn Indrestrand | Danish Ocean Cluster | 100% |
| Speaker 8 | Monika Poulsen | ACT Cluster Norway | 100% |

**Total**: 6 speakers identified with 95-100% confidence
