# 04-Social-Media

Platform-ready social media content for LinkedIn, Twitter/X, and Instagram

## Contents

7 JSON files containing **160+ posts** across **194,199 characters**

| File | Posts | Platforms | Focus |
|------|-------|-----------|-------|
| `session-1-posts.json` | 20+ | All | Technology & Digital Infrastructure |
| `session-2-posts.json` | 10+ | All | Blue Economy & Ocean Solutions |
| `session-3-posts.json` | 30+ | All | Community & Indigenous Knowledge |
| `session-4-posts.json` | 25+ | All | Arctic Lifestyles & Culture |
| `session-5-posts.json` | 40+ | All | Circular Cities & Construction |
| `session-day1-summary-posts.json` | 15+ | All | Day 1 Synthesis |
| `day1-holistic-posts.json` | 20+ | All | Cross-Session Themes |

## JSON Structure

Each post includes:

```json
{
  "platform": "linkedin",
  "content": "Post text content...",
  "hashtags": ["#CircularEconomy", "#ArcticInnovation", ...],
  "character_count": 280,
  "theme": "Trust as Infrastructure",
  "sessions_referenced": ["session-1", "session-4"],
  "speaker_attribution": "Speaker Name - Organization (optional)",
  "image_suggestions": "Visual description (optional)"
}
```

## Platform Specifications

### LinkedIn
- Character limit: 3000 (most posts 250-500)
- Format: Professional, detailed
- Hashtags: 3-5 strategic tags
- Best for: Thought leadership, case studies, longer insights

### Twitter/X
- Character limit: 280
- Format: Concise, punchy
- Hashtags: 2-3 targeted tags
- Best for: Quick facts, quotes, announcements

### Instagram
- Character limit: 2200 (most posts 150-300)
- Format: Visual-first, storytelling
- Hashtags: 5-10 discovery tags
- Best for: Stories, visuals, behind-the-scenes, inspiration

## Content Categories

### Quotes (30%)
Direct quotes from speakers with attribution

### Insights (25%)
Key takeaways and strategic implications

### Case Studies (20%)
Specific innovations and examples

### Data Points (15%)
Statistics and numbers with context

### Questions (10%)
Thought-provoking engagement posts

## Hashtag Strategy

### Core Tags (Use consistently)
- #CircularEconomy
- #NordicCircularSummit
- #ArcticInnovation
- #Sustainability

### Theme-Specific Tags
- #BlueEconomy (Session 2)
- #IndigenousKnowledge (Session 3)
- #CircularCities (Session 5)
- #ArcticLifestyle (Session 4)

### Geographic Tags
- #Greenland
- #Nuuk
- #ArcticCircle
- #NordicCountries

## Usage Recommendations

### Immediate Use
Posts are ready to copy-paste to platforms

### Customization
- Add event photos/graphics
- Adjust hashtags for your audience
- Include event links
- Tag speakers/organizations

### Scheduling
- Spread posts over weeks/months
- Peak times: Weekdays 8-10am, 12-2pm (CET)
- Mix content types for variety

### Analytics
Track engagement by:
- Theme
- Format (quote vs insight vs data)
- Platform
- Timing

## Best Practices

### Do:
✓ Tag speakers and organizations (with permission)
✓ Include visual content when possible
✓ Respond to comments and engagement
✓ Cross-reference related posts
✓ Credit sources appropriately

### Don't:
✗ Post all at once (avoid spam)
✗ Use too many hashtags (looks desperate)
✗ Ignore platform-specific best practices
✗ Forget to track what works
✗ Neglect to engage with responses

## Image Suggestions

Many posts include `image_suggestions` field with ideas for accompanying visuals:
- Session photos
- Speaker headshots
- Data visualizations
- Infographics
- Arctic/Greenland imagery
- Circular economy diagrams

## Related Content

- `02-Articles/` - Source material for posts
- `03-Highlights/` - Quotes used in posts
- `05-Executive-Summaries/` - Strategic themes for posts
- `01-Transcripts/` - Full context and additional quotes

## Content Calendar Suggestion

**Week 1-2 (Post-Event):**
- Event highlights and thank you posts
- Key quotes from each session
- Photo galleries

**Week 3-4:**
- Deeper insights and analysis
- Case studies and innovations
- Speaker spotlights

**Week 5-8:**
- Cross-session themes
- Strategic implications
- Call to action posts

**Ongoing:**
- Evergreen content about circular economy
- Updates on featured initiatives
- Community engagement

## Tools Integration

Import JSON files into:
- **Hootsuite** - Bulk scheduling
- **Buffer** - Content planning
- **Sprout Social** - Analytics
- **Later** - Visual planning (Instagram)
- **Custom tools** - API integration

## Compliance

- All quotes have speaker attribution
- Content respects event guidelines
- Sensitive topics handled appropriately
- Privacy considerations included
