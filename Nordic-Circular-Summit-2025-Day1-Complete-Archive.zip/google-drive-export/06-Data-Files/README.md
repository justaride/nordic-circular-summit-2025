# 06-Data-Files

Structured data files for analysis, visualization, and custom processing

## Contents

**1 file:** `day1-master.json` (11,057 bytes)

## Overview

Aggregated structured data combining all 6 Day 1 sessions into a single comprehensive dataset for:
- Quantitative analysis
- Data visualization
- Custom reporting
- Database import
- API integration
- Research applications

## Data Structure

### Top-Level Schema

```json
{
  "metadata": {
    "event": "Nordic Circular Summit 2025 - Day 1",
    "date": "2025-11-19",
    "location": "Katuaq Cultural Center, Nuuk, Greenland",
    "session_count": 6,
    "total_duration_minutes": 330,
    "total_speakers": 24,
    "total_words": 28819,
    "total_quotes": 60,
    "unique_themes": 48,
    "generated_at": "2025-11-20T11:02:00Z"
  },
  "sessions": [...],
  "aggregated": {...}
}
```

### Sessions Array
Each session object includes:
```json
{
  "session_id": "session-1",
  "title": "Circular Frontiers",
  "duration_minutes": 60,
  "speaker_count": 5,
  "word_count": 49585,
  "themes": [...],
  "quotes": [...],
  "speakers": [...]
}
```

### Aggregated Data
Cross-session analytics:
```json
{
  "all_quotes": [
    {
      "quote": "...",
      "speaker": "...",
      "session_id": "...",
      "theme": "...",
      "timestamp": "..."
    }
  ],
  "all_themes": [
    {
      "theme": "Trust as Infrastructure",
      "frequency": 15,
      "sessions": ["session-1", "session-2", ...]
    }
  ],
  "speaker_statistics": {
    "total_speakers": 24,
    "by_session": {...},
    "by_sector": {...}
  },
  "cross_session_themes": [...]
}
```

## Use Cases

### Data Visualization
Import into visualization tools:
- **Tableau** - Interactive dashboards
- **Power BI** - Business intelligence
- **D3.js** - Custom web visualizations
- **Python (matplotlib, seaborn)** - Statistical plots
- **R (ggplot2)** - Research visualizations

### Analysis
Process with analysis tools:
- **Python (pandas, numpy)** - Data analysis
- **R (tidyverse)** - Statistical analysis
- **Excel/Google Sheets** - Spreadsheet analysis
- **SQL databases** - Structured queries

### Integration
Import into systems:
- **CMS platforms** - Content management
- **CRM systems** - Contact management
- **Databases** - PostgreSQL, MongoDB, etc.
- **APIs** - Custom applications
- **Research tools** - Qualitative analysis software

### Reporting
Generate custom reports:
- Session comparisons
- Theme frequency analysis
- Speaker contribution metrics
- Word cloud generation
- Timeline visualizations

## Example Analyses

### Theme Frequency Analysis
Count and rank themes across all sessions

### Speaker Network Mapping
Visualize connections between speakers and topics

### Session Comparison
Compare metrics across sessions

### Quote Extraction
Filter quotes by theme, speaker, or session

### Word Frequency
Identify most common terms and concepts

### Timeline Visualization
Map theme evolution across Day 1

## Import Instructions

### Python
```python
import json

with open('day1-master.json', 'r') as f:
    data = json.load(f)

# Access metadata
print(data['metadata']['session_count'])

# Iterate sessions
for session in data['sessions']:
    print(session['title'])

# Analyze themes
themes = data['aggregated']['all_themes']
```

### R
```r
library(jsonlite)

data <- fromJSON('day1-master.json')

# Access metadata
data$metadata$session_count

# Convert to dataframe
sessions_df <- as.data.frame(data$sessions)
```

### JavaScript/Node.js
```javascript
const fs = require('fs');

const data = JSON.parse(
  fs.readFileSync('day1-master.json', 'utf8')
);

// Access metadata
console.log(data.metadata.session_count);

// Filter sessions
const sessions = data.sessions.filter(s =>
  s.duration_minutes > 60
);
```

### Excel/Google Sheets
1. Import JSON using Power Query (Excel) or Apps Script (Sheets)
2. Flatten nested structures as needed
3. Create pivot tables and charts

## Data Quality

- ✓ All quotes verified against transcripts
- ✓ Speaker attributions validated
- ✓ Themes categorized consistently
- ✓ Timestamps in standard format (HH:MM:SS)
- ✓ Word counts accurate
- ✓ Cross-references validated

## Notes

- UTF-8 encoded
- Valid JSON structure (validated)
- Consistent naming conventions
- All arrays are properly formatted
- Null values used for missing data (not empty strings)
- Timestamps use 24-hour format

## Related Content

**Source Material:**
- `01-Transcripts/*.json` - Individual session JSONs
- `01-Transcripts/*-CLEAN.md` - Transcript text

**Analysis Outputs:**
- `03-Highlights/day1-by-the-numbers.md` - Statistical analysis
- `03-Highlights/day1-cross-session-themes.md` - Theme analysis
- `05-Executive-Summaries/` - Strategic synthesis

## Support

For questions about data structure or custom analysis needs:
- Review the JSON directly in a text editor
- Use online JSON validators for structure verification
- Refer to transcripts for additional context
- Check documentation files for methodology

## Version

- **Data version:** 1.0
- **Generated:** November 20, 2025
- **Source:** Sessions 1-5 + Day 1 Summary
- **Last updated:** November 20, 2025
